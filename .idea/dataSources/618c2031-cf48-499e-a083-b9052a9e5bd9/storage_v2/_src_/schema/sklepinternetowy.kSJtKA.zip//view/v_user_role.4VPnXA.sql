create definer = root@localhost view v_user_role as
select `u`.`Login` AS `Login`, `u`.`Haslo` AS `Haslo`, `g`.`group_name` AS `group_name`
from ((`sklepinternetowy`.`user_groups` `ug` join `sklepinternetowy`.`osoba` `u` on ((`u`.`idOsoba` = `ug`.`idOsoba`)))
         join `sklepinternetowy`.`groups` `g` on ((`g`.`group_id` = `ug`.`group_id`)));

